# Technical Writer Assignment

## [Task 1](./task1/index.md) (System Architecture Docs)
## [Task 2](./task2/index.md) (Swagger API exercise)
## [Task 3](./task3/index.md) (English text rewriting exercise)