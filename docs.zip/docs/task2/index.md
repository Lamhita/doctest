# OpenAPI Specification

This page renders the OpenAPI specification using Swagger UI.

## OpenAPI Definition

!!swagger openapi.yaml!!